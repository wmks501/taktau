Pickaxe 3x3 (Fabric, Minecraft Java 26.2)

Build:
1. Pakai JDK 25.
2. Folder ini belum ada gradlew / gradle-wrapper.jar. Salin gradlew, gradlew.bat,
   dan gradle/wrapper/gradle-wrapper.jar dari proyek mod kamu yang lain
   (atau jalankan "gradle wrapper" kalau Gradle sudah terpasang).
3. Jalankan: ./gradlew build   (Windows: gradlew.bat build)
4. Hasil jar: build/libs/pickaxe3x3-1.0.0.jar -> taruh di folder mods bersama Fabric API.

Tes cepat: ./gradlew runClient
Tombol Z = toggle mining 3x3 (bisa diganti di Controls).
