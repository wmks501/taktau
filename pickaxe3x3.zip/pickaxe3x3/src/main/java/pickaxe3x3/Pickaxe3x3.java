package pickaxe3x3;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;

public class Pickaxe3x3 implements ModInitializer {
    private static final Set<UUID> ENABLED = new HashSet<>();
    private static boolean breaking = false; // cegah rekursi

    @Override
    public void onInitialize() {
        PayloadTypeRegistry.playC2S().register(TogglePayload.TYPE, TogglePayload.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(TogglePayload.TYPE, (payload, ctx) -> {
            ServerPlayer p = ctx.player();
            boolean on = ENABLED.add(p.getUUID());
            if (!on) ENABLED.remove(p.getUUID());
            p.displayClientMessage(Component.literal("Mining 3x3: " + (on ? "ON" : "OFF")), true);
        });

        // BEFORE: blok tengah masih ada, jadi sisi yang dipukul masih bisa dicari
        PlayerBlockBreakEvents.BEFORE.register((level, player, pos, state, be) -> {
            if (breaking || !(player instanceof ServerPlayer sp)) return true;
            if (!ENABLED.contains(sp.getUUID())) return true;

            ItemStack tool = sp.getMainHandItem();
            if (!tool.is(ItemTags.PICKAXES)) return true;

            HitResult hit = sp.pick(sp.blockInteractionRange() + 1.0, 1.0f, false);
            if (!(hit instanceof BlockHitResult bhr) || !bhr.getBlockPos().equals(pos)) return true;
            Direction.Axis axis = bhr.getDirection().getAxis();

            breaking = true;
            try {
                for (int a = -1; a <= 1; a++) {
                    for (int b = -1; b <= 1; b++) {
                        if (a == 0 && b == 0) continue;
                        BlockPos t = switch (axis) {
                            case X -> pos.offset(0, a, b);
                            case Y -> pos.offset(a, 0, b);
                            case Z -> pos.offset(a, b, 0);
                        };
                        BlockState s = level.getBlockState(t);
                        if (s.isAir() || s.getDestroySpeed(level, t) < 0) continue;
                        if (!tool.isCorrectToolForDrops(s)) continue;
                        if (sp.getMainHandItem().isEmpty()) break; // pickaxe sudah pecah
                        sp.gameMode.destroyBlock(t); // drop + durability diurus vanilla
                    }
                }
            } finally {
                breaking = false;
            }
            return true; // blok tengah dihancurkan normal
        });
    }
}
