package pickaxe3x3;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

public record TogglePayload() implements CustomPacketPayload {
    public static final Type<TogglePayload> TYPE =
        new Type<>(Identifier.fromNamespaceAndPath("pickaxe3x3", "toggle"));
    public static final StreamCodec<RegistryFriendlyByteBuf, TogglePayload> CODEC =
        StreamCodec.unit(new TogglePayload());

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
